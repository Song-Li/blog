/*
 * WebGL Water
 * http://madebyevan.com/webgl-water/
 *
 * Copyright 2011 Evan Wallace
 * Released under the MIT license
 */
Uint8Array.prototype.hashCode = function() {
    var hash = 0, i, chr, len;
    if (this.length === 0) return hash;
    for (i = 0, len = this.length; i < len; i++) {
        chr   = this[i];
        hash  = ((hash << 5) - hash) + chr;        
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

String.prototype.hashCode = function() {
    var hash = 0, i, chr, len;
    if (this.length === 0) return hash;
    for (i = 0, len = this.length; i < len; i++) {
        chr   = this.charCodeAt(i);
        hash  = ((hash << 5) - hash) + chr;        
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

function text2html(text) {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
}

function handleError(text) {
    var html = text2html(text);
    if (html == 'WebGL not supported') {
        html = 'Your browser does not support WebGL.<br>Please see\
               <a href="http://www.khronos.org/webgl/wiki/Getting_a_WebGL_Implementation">\
               Getting a WebGL Implementation</a>.';
    }
    var loading = document.getElementById('loading');
}


var gl = GL.create();
var water;
var cubemap;
var renderer;
var angleX = -25;
var angleY = -200.5;
var counter = 0;

// Sphere physics info
var useSpherePhysics = false;
var center;
var oldCenter;
var velocity;
var gravity;
var radius;
var paused = false;

window.onload = function() {
    var ratio = window.devicePixelRatio || 1;
    var help = document.getElementById('help');
    var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    if(debugInfo){
        var ven = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
        var ren = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);

        console.log(ven);
        console.log(ren);
    }else{
        console.log("debugInfo is not accessable");
    }

    function onresize() {
        var width = 800;
        var height = 800;
        gl.canvas.width = width * ratio;
        gl.canvas.height = height * ratio;
        gl.canvas.style.width = width + 'px';
        gl.canvas.style.height = height + 'px';
        gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
        gl.matrixMode(gl.PROJECTION);
        gl.loadIdentity();
        gl.perspective(45, gl.canvas.width / gl.canvas.height, 0.01, 100);
        gl.matrixMode(gl.MODELVIEW);
        draw();
    }

    document.body.appendChild(gl.canvas);

    water = new Water();
    renderer = new Renderer();
    cubemap = new Cubemap({
        xneg: document.getElementById('xneg'),
            xpos: document.getElementById('xpos'),
            yneg: document.getElementById('ypos'),
            ypos: document.getElementById('ypos'),
            zneg: document.getElementById('zneg'),
            zpos: document.getElementById('zpos')
    });

    if (!water.textureA.canDrawTo() || !water.textureB.canDrawTo()) {
        throw new Error('Rendering to floating-point textures is required but not supported');
    }

    center = oldCenter = new GL.Vector(-0.4, -0.75, 0.2);
    velocity = new GL.Vector();
    gravity = new GL.Vector(0, -4, 0);
    radius = 0.25;

    for (var i = 0; i < 20; i++) {
        water.addDrop(i * 0.05 * 2 - 1, (1 - i * 0.05) * 2 - 1, 0.03, (i & 1) ? 0.01 : -0.01);
    }

    onresize();

    var requestAnimationFrame =
        window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        function(callback) { setTimeout(callback, 0); };

    function animate() {
        update(1);
        draw();
        requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);

    var prevHit;
    var planeNormal;
    var mode = -1;
    var MODE_ADD_DROPS = 0;
    var MODE_MOVE_SPHERE = 1;
    var MODE_ORBIT_CAMERA = 2;

    var oldX, oldY;

    function startDrag(x, y) {
        oldX = x;
        oldY = y;
        var tracer = new GL.Raytracer();
        var ray = tracer.getRayForPixel(x * ratio, y * ratio);
        var pointOnPlane = tracer.eye.add(ray.multiply(-tracer.eye.y / ray.y));
        var sphereHitTest = GL.Raytracer.hitTestSphere(tracer.eye, ray, center, radius);
        if (sphereHitTest) {
            mode = MODE_MOVE_SPHERE;
            prevHit = sphereHitTest.hit;
            planeNormal = tracer.getRayForPixel(gl.canvas.width / 2, gl.canvas.height / 2).negative();
        } else if (Math.abs(pointOnPlane.x) < 1 && Math.abs(pointOnPlane.z) < 1) {
            mode = MODE_ADD_DROPS;
            duringDrag(x, y);
        } else {
            mode = MODE_ORBIT_CAMERA;
        }
    }

    function duringDrag(x, y) {
        switch (mode) {
            case MODE_ADD_DROPS: {
                var tracer = new GL.Raytracer();
                var ray = tracer.getRayForPixel(x * ratio, y * ratio);
                var pointOnPlane = tracer.eye.add(ray.multiply(-tracer.eye.y / ray.y));
                water.addDrop(pointOnPlane.x, pointOnPlane.z, 0.03, 0.01);
                if (paused) {
                    water.updateNormals();
                    renderer.updateCaustics(water);
                }
                break;
            }
            case MODE_MOVE_SPHERE: {
                var tracer = new GL.Raytracer();
                var ray = tracer.getRayForPixel(x * ratio, y * ratio);
                var t = -planeNormal.dot(tracer.eye.subtract(prevHit)) / planeNormal.dot(ray);
                var nextHit = tracer.eye.add(ray.multiply(t));
                center = center.add(nextHit.subtract(prevHit));
                center.x = Math.max(radius - 1, Math.min(1 - radius, center.x));
                center.y = Math.max(radius - 1, Math.min(10, center.y));
                center.z = Math.max(radius - 1, Math.min(1 - radius, center.z));
                prevHit = nextHit;
                if (paused) renderer.updateCaustics(water);
                break;
            }
            case MODE_ORBIT_CAMERA: {
                angleY -= x - oldX;
                angleX -= y - oldY;
                angleX = Math.max(-89.999, Math.min(89.999, angleX));
                break;
            }
        }
        oldX = x;
        oldY = y;
    }

    function stopDrag() {
        mode = -1;
    }

    var frame = 0;

    function update(seconds) {
        if (seconds > 1) return;
        frame += seconds * 2;

        // Start from rest when the player releases the mouse after moving the sphere
        velocity = new GL.Vector();

        // Displace water around the sphere
        water.moveSphere(oldCenter, center, radius);
        oldCenter = center;

        // Update the water simulation and graphics
        water.stepSimulation();
        water.stepSimulation();
        water.updateNormals();
        renderer.updateCaustics(water);
    }

    function saveAs(file){
        var downloadLink = document.createElement("a");
        downloadLink.download = "ex";
        downloadLink.innerHTML = "Download File";
        downloadLink.href = file;
        downloadLink.style.display = "none";
        document.body.appendChild(downloadLink);

        downloadLink.click();
    }
    var pixels = new Uint8Array(655350);

    function draw() {
        if(counter == 1){ 
           // saveAs(gl.canvas.toDataURL('image/png'));
        }
        counter ++;

        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        gl.loadIdentity();
        gl.translate(0, 0, -4);
        gl.rotate(-angleX, 1, 0, 0);
        gl.rotate(-angleY, 0, 1, 0);
        gl.translate(0, 0.5, 0);

        gl.enable(gl.DEPTH_TEST);
        renderer.sphereCenter = center;
        renderer.sphereRadius = radius;
        renderer.renderCube();
        renderer.renderWater(water, cubemap);
        renderer.renderSphere();
        gl.disable(gl.DEPTH_TEST);

        if(counter == 30){
//            window.open(gl.canvas.toDataURL('image/png'));
//            saveAs(gl.canvas.toDataURL('image/png'));
            gl.readPixels(0,0,300,300,gl.RGBA, gl.UNSIGNED_BYTE, pixels); // canvas.getContext("2D".getImageData(0,0,800,600).data;
            console.log(pixels.hashCode());
        }
        if(counter == 50){ 
  //          document.location.reload();
        }
        if(counter < 50){
            gl.readPixels(0,0,300,300,gl.RGBA, gl.UNSIGNED_BYTE, pixels); // canvas.getContext("2D".getImageData(0,0,800,600).data;
           // console.log(pixels.hashCode());
        }
    }
};
